package com.dicoding.githubuserapp.adapter

import org.junit.Assert.*

import org.junit.Test

class ListUserAdapterTest {

    @Test
    fun setOnItemClickCallback() {
    }

    @Test
    fun setList() {
    }

    @Test
    fun onCreateViewHolder() {
    }

    @Test
    fun onBindViewHolder() {
    }

    @Test
    fun getItemCount() {
    }
}