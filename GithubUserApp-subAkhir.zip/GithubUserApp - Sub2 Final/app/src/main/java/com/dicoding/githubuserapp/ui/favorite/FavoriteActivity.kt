package com.dicoding.githubuserapp.ui.favorite

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import com.dicoding.githubuserapp.adapter.ListUserAdapter
import com.dicoding.githubuserapp.databinding.ActivityFavoriteBinding
import com.dicoding.githubuserapp.local.UserFav
import com.dicoding.githubuserapp.ui.detail.DetailActivity
import com.dicoding.githubuserapp.user.User
import com.dicoding.githubuserapp.viewmodel.FavoriteViewModel

class FavoriteActivity : AppCompatActivity() {

    private lateinit var binding : ActivityFavoriteBinding
    private lateinit var adapter : ListUserAdapter
    private lateinit var favViewModel : FavoriteViewModel

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityFavoriteBinding.inflate(layoutInflater)
        setContentView(binding.root)

        supportActionBar?.setDisplayShowHomeEnabled(true)

        adapter = ListUserAdapter()
        adapter.notifyDataSetChanged()


        favViewModel = ViewModelProvider(this)[FavoriteViewModel::class.java]

        binding.apply {
            rvFavorite.setHasFixedSize(true)
            rvFavorite.layoutManager = LinearLayoutManager(this@FavoriteActivity)
            rvFavorite.adapter = adapter
        }

        favViewModel.getUserFav()?.observe(this) {
            if (it != null) {
                showLoading(true)
                val list = mapList(it)
                adapter.setList(list)
                showEmpty(false)
            }
            if (it.isEmpty()){
                showEmpty(true)
            }
            showLoading(false)
        }

        adapter.setOnItemClickCallback(object : ListUserAdapter.OnItemClickCallback {
            override fun onItemClicked(data: User) {
                showSelectedUser(data)
            }
        })

    }

    private fun mapList(users: List<UserFav>): ArrayList<User> {
        showLoading(true)
        val listUsers = ArrayList<User>()
        for (user in users){
            val userMapped = User(
                user.login,
                user.id,
                user.avatar_url
            )
            listUsers.add(userMapped)
        }
        showLoading(false)
        return listUsers
    }

    private fun showLoading(state: Boolean) {
        binding.progressBar.visibility = if (state) View.VISIBLE else View.GONE
    }

    private fun showEmpty(state: Boolean) {
        binding.notFound.visibility = if (state) View.VISIBLE else View.GONE
    }

    private fun showSelectedUser(user: User) {
        Toast.makeText(this, "Kamu Memilih " + user.login, Toast.LENGTH_SHORT).show()
        val intent = Intent(this@FavoriteActivity, DetailActivity::class.java)
        intent.putExtra(DetailActivity.EXTRA_USER, user)
        intent.putExtra(DetailActivity.EXTRA_ID, user.id)
        intent.putExtra(DetailActivity.EXTRA_URL, user.avatar_url)
        startActivity(intent)
    }
}