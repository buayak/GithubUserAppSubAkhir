package com.dicoding.githubuserapp.viewmodel

import android.app.Application
import android.util.Log
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import com.dicoding.githubuserapp.local.UserDatabase
import com.dicoding.githubuserapp.local.UserFav
import com.dicoding.githubuserapp.local.UserFavDao
import com.dicoding.githubuserapp.network.ApiConfig
import com.dicoding.githubuserapp.user.UserDetail
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.launch
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class DetailViewModel(application: Application) : AndroidViewModel(application) {
    private val _userDetail = MutableLiveData<UserDetail>()

    private var userDao: UserFavDao?
    private var userDB: UserDatabase?

    init{
        userDB = UserDatabase.getDatabase(application)
        userDao = userDB?.userFavDao()
    }

    fun setUserDetail(username: String) {
        val client = ApiConfig.apiInstance.getDetailUsers(username)

        client.enqueue(object : Callback<UserDetail> {
            override fun onResponse(
                call: Call<UserDetail>,
                response: Response<UserDetail>
            ) {
                if(response.isSuccessful){
                    _userDetail.postValue(response.body())
                }
            }

            override fun onFailure(call: Call<UserDetail>, t: Throwable) {
                Log.e("DetailViewModel", "onFailure setUserDetail ${t.message}")
            }
        })
    }

    fun getUserDetail(): LiveData<UserDetail>{
        return _userDetail
    }

    fun addToFavorite(username: String, id: Int, avatarUrl: String){
        CoroutineScope ( Dispatchers.IO ).launch{
            var user = UserFav(
                username,
                id,
                avatarUrl
            )
            userDao?.addToFavorite(user)
        }
    }

    fun checkUser(id: Int) = userDao?.checkUser(id)

    fun removeFromFavorite(id: Int){
        CoroutineScope ( Dispatchers.IO ).launch{
            userDao?.removeUserFav(id)
        }
    }
}