package com.dicoding.githubuserapp.local

import androidx.lifecycle.LiveData
import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query

@Dao
interface UserFavDao {
    @Insert
    fun addToFavorite(userFav: UserFav)

    @Query("SELECT * FROM favorite_user")
    fun getUserFav(): LiveData<List<UserFav>>

    @Query("SELECT count(*) FROM favorite_user WHERE favorite_user.id = :id")
    fun checkUser(id: Int): Int

    @Query("DELETE FROM favorite_user WHERE favorite_user.id = :id")
    fun removeUserFav(id: Int): Int
}