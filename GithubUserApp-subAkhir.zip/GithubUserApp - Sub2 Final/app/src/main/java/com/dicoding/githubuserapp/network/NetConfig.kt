package com.dicoding.githubuserapp.network

object NetConfig{
    const val GITHUB_TOKEN = "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"
    const val BASE_URL = "https://api.github.com/"

}