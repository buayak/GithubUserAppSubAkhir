package com.dicoding.githubuserapp.ui.detail.follow

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import com.dicoding.githubuserapp.adapter.ListUserAdapter
import com.dicoding.githubuserapp.databinding.FragmentFollowBinding
import com.dicoding.githubuserapp.ui.detail.DetailActivity
import com.dicoding.githubuserapp.user.User
import com.dicoding.githubuserapp.viewmodel.FollowViewModel


class FollowingFragment : Fragment(),
    ListUserAdapter.OnItemClickCallback {
    private var _binding: FragmentFollowBinding? = null
    private val binding get() = _binding!!
    private val userAdapter = ListUserAdapter()

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentFollowBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        val extraUser =
            activity?.intent?.getParcelableExtra<User>(DetailActivity.EXTRA_USER) as User

        extraUser.login?.let { setupViewModel(it) }

        setupRecyclerView()
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }

    private fun setupViewModel(username: String) {
        showLoading(true)
        val followViewModel = ViewModelProvider(
            this,
            ViewModelProvider.NewInstanceFactory()
        )[FollowViewModel::class.java]

        followViewModel.setFollowing(username)


        followViewModel.follow.observe(viewLifecycleOwner) {
            if (it != null) {
                userAdapter.setList(it)
                showEmpty(false)
            }
            if (it.isEmpty()) {
                showEmpty(true)
            }
            showLoading(false)
        }
    }

    private fun showEmpty(state: Boolean) {
        binding.notFound.visibility = if (state) View.VISIBLE else View.GONE
    }


    private fun showLoading(state: Boolean) {
        binding.progressBar.visibility = if (state) View.VISIBLE else View.GONE
    }

    private fun setupRecyclerView() {
        with(binding) {
            rvUser.setHasFixedSize(true)
            rvUser.layoutManager = LinearLayoutManager(requireContext())
            rvUser.adapter = userAdapter
        }
    }

    override fun onItemClicked(data: User) {
        val userDetailIntent = Intent(requireActivity(), DetailActivity::class.java)
        userDetailIntent.putExtra(DetailActivity.EXTRA_USER, data)
        startActivity(userDetailIntent)
    }
}