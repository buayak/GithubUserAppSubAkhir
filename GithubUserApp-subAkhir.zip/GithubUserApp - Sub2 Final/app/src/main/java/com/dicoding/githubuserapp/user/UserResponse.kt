package com.dicoding.githubuserapp.user

data class UserResponse(
    val items : ArrayList<User>
)