package com.dicoding.githubuserapp.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import com.dicoding.githubuserapp.local.UserDatabase
import com.dicoding.githubuserapp.local.UserFav
import com.dicoding.githubuserapp.local.UserFavDao

class FavoriteViewModel(application: Application) : AndroidViewModel(application) {
    private var userDao: UserFavDao?
    private var userDB: UserDatabase?

    init{
        userDB = UserDatabase.getDatabase(application)
        userDao = userDB?.userFavDao()
    }

    fun getUserFav(): LiveData<List<UserFav>>?{
        return userDao?.getUserFav()
    }
}