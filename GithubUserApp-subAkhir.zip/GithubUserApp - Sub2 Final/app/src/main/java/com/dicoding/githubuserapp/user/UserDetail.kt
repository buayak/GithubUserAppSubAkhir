package com.dicoding.githubuserapp.user

import com.google.gson.annotations.SerializedName

data class UserDetail(
    val login: String? = null,
    val id: Int? = null,
    val name: String? = null,
    val type: String? = null,
    val avatar_url: String? = null,
    val followers: Int? = null,
    val following: Int? = null,
    val company: String? = null,
    val location: String? = null,
    @SerializedName("public_repos")
    val publicRepos: String? = null
)
